﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Globalization;
using TiendaVehiculos.EN;

namespace TiendaVehiculos.CAD
{
    public class CochesCAD
    {
        public static DataTable llenar()
        {
            return null;
        }
        public static DataTable producto()
        {
            return null;
        }
        public static CochesEN Datosarticulo()
        {
            return null;
        }
        public static DataTable Buscador()
        {
            return null;
        }
        public static DataTable Categorias()
        {
            return null;
        }
    }

}
