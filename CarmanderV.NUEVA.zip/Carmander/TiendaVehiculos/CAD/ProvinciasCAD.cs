﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Globalization;
using Libreria.EN;
using System.Collections;

namespace Libreria.CAD
{
    class ProvinciasCAD
    {
        public ArrayList ObtenerProvincias() {
            return null;
        }
        public void InsertarProvincia() { }
        public void BorrarProvincia() { }
        public void ModificarProvincia() { }
        public ProvinciasEN ObtenerProvinciaPorId() {
            return null;
        }
    

    }
}
