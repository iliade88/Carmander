﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace TiendaVehiculos.CAD
{
	public class ArticuloCAD
	{
		private ConexionCAD conexion;
        private SqlCommand consulta;
        private SqlDataReader lector;
        private ArrayList lista;
		
		
		
		
	}
 
}
