﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Globalization;
using Libreria.EN;

namespace Libreria.CAD
{
    class Cliente
    {
        public void AgregarCliente() { }
        public static bool clienteesta() {
            return true;
        }
        public static ClientesEN clientelogueado() {
            
                return null;
            }

        public static bool clientyaregistrado() {
            return true;
        }
        public void modificarCliente() { 
            
        }
        public void bajacuentaCliente() { 
        }
    }
}
